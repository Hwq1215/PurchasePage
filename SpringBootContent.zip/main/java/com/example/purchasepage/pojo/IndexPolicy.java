package com.example.purchasepage.pojo;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class IndexPolicy {
    String title;
    String url;
}
